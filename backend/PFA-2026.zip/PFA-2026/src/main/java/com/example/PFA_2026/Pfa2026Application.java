package com.example.PFA_2026;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pfa2026Application {

	public static void main(String[] args) {
		SpringApplication.run(Pfa2026Application.class, args);
	}

}
